"""
Saree AI — Minimal Gradio starter app

This starter app provides:
- A Gradio UI that generates a tileable saree body pattern (via SDXL pipeline)
- Composites the tile onto a flat saree template using an uploaded body mask
- Simple instructions to extend with LoRA/ControlNet

NOTE: This script expects SDXL model access (Hugging Face or local). See README.
"""

import os
import math
from typing import Optional
from PIL import Image
import gradio as gr
import torch

# Try importing diffusers; if not installed, instructions are in requirements.txt
try:
    from diffusers import StableDiffusionXLPipeline, StableDiffusionXLImg2ImgPipeline
except Exception as e:
    raise RuntimeError("Please install required packages (see requirements.txt).") from e

MODEL_ID = os.environ.get("SDXL_MODEL", "stabilityai/stable-diffusion-xl-base-1.0")
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
OUT_DIR = "outputs"
os.makedirs(OUT_DIR, exist_ok=True)

def load_pipelines(model_id: str):
    pipe_t2i = StableDiffusionXLPipeline.from_pretrained(
        model_id,
        torch_dtype=torch.float16 if DEVICE=="cuda" else torch.float32
    ).to(DEVICE)
    pipe_i2i = StableDiffusionXLImg2ImgPipeline.from_pretrained(
        model_id,
        torch_dtype=torch.float16 if DEVICE=="cuda" else torch.float32
    ).to(DEVICE)
    try:
        pipe_t2i.enable_vae_tiling()
        pipe_i2i.enable_vae_tiling()
    except Exception:
        pass
    return pipe_t2i, pipe_i2i

PIPE_T2I, PIPE_I2I = load_pipelines(MODEL_ID)

DEFAULT_PROMPT = "intricate indian floral buti repeat, paisley accents, seamless repeat, rich textile detail"
NEGATIVE_PROMPT = "text, logo, watermark, face, messy background"

def make_tile_from_prompt(prompt, negative, seed=None, width=1024, height=1024, steps=30, guidance=6.0):
    generator = torch.manual_seed(seed) if seed is not None else None
    out = PIPE_T2I(prompt=prompt, negative_prompt=negative, width=width, height=height,
                   guidance_scale=guidance, num_inference_steps=steps, generator=generator, output_type="pil")
    return out.images[0]

def composite_tile_on_body(flat_template: Image.Image, body_mask: Image.Image, tile: Image.Image):
    W, H = flat_template.size
    tW, tH = tile.size
    reps_x = math.ceil(W / tW) + 1
    reps_y = math.ceil(H / tH) + 1
    big = Image.new("RGBA", (tW * reps_x, tH * reps_y))
    for x in range(reps_x):
        for y in range(reps_y):
            big.paste(tile, (x * tW, y * tH))
    big = big.crop((0, 0, W, H))
    body_mask_rgba = body_mask.convert("L")
    base = flat_template.convert("RGBA")
    composed = Image.composite(big, base, body_mask_rgba)
    return composed.convert("RGB")

with gr.Blocks(title="Saree AI — Starter") as demo:
    gr.Markdown("# Saree AI — Starter\nGenerate a tileable saree print and composite on a flat saree template.")
    with gr.Row():
        with gr.Column(scale=2):
            prompt = gr.Textbox(label="Tile prompt", value=DEFAULT_PROMPT, lines=3)
            negative = gr.Textbox(label="Negative prompt", value=NEGATIVE_PROMPT, lines=2)
            seed = gr.Number(label="Seed (-1 = random)", value=-1)
            tile_w = gr.Dropdown(label="Tile Width", choices=[512, 768, 1024], value=1024)
            tile_h = gr.Dropdown(label="Tile Height", choices=[512, 768, 1024], value=1024)
            steps = gr.Slider(5, 50, value=30, label="Steps")
            guidance = gr.Slider(1.0, 20.0, value=6.0, label="Guidance Scale")
            flat_template = gr.File(label="Flat saree template (PNG/JPG)")
            body_mask = gr.File(label="Body mask (white=tile area)")
            generate_btn = gr.Button("Generate")
        with gr.Column(scale=1):
            tile_out = gr.Image(label="Generated tile")
            composite_out = gr.Image(label="Composite on template")
            status = gr.Textbox(label="Status / logs", value="Ready", lines=6)

    def generate_fn(prompt, negative, seed, tile_w, tile_h, steps, guidance, flat_template, body_mask):
        seed_used = None if seed == -1 or seed is None else int(seed)
        try:
            tile = make_tile_from_prompt(prompt, negative, seed_used, tile_w, tile_h, steps, guidance)
        except Exception as e:
            return None, None, f\"Tile generation failed: {e}\"
        if flat_template is None or body_mask is None:
            return tile, None, \"Please upload a flat template and a body mask.\"
        template = Image.open(flat_template).convert(\"RGB\")
        body_mask_img = Image.open(body_mask).convert(\"L\")
        composite = composite_tile_on_body(template, body_mask_img, tile)
        out_tile = os.path.join(OUT_DIR, \"tile.png\")
        out_comp = os.path.join(OUT_DIR, \"composite.png\")
        tile.save(out_tile)
        composite.save(out_comp)
        return tile, composite, f\"Saved: {out_tile}, {out_comp}\"

    generate_btn.click(generate_fn, inputs=[prompt, negative, seed, tile_w, tile_h, steps, guidance, flat_template, body_mask],
                       outputs=[tile_out, composite_out, status])

if __name__ == \"__main__\":
    demo.launch(server_name=\"0.0.0.0\", share=True)
