# Saree AI

Minimal Saree AI starter project.

## What is inside
- `app/saree_ai_gradio_app.py`: Minimal Gradio app to generate saree tiles and composite on a flat template.
- `requirements.txt`: Python dependencies.
- `colab_notebook.ipynb`: A notebook to run the app in Google Colab (one-click).
- `.gitignore`: Common ignores.

## Quick start (Google Colab)
1. Open Google Colab, create a new notebook.
2. Run:
```python
!git clone https://github.com/<your-username>/saree-ai.git
%cd saree-ai
!pip install -r requirements.txt
!python app/saree_ai_gradio_app.py
```
3. When the app launches, click the public Gradio link.

## Notes
- You need access to Stable Diffusion XL weights (e.g., via Hugging Face) to run the model.
- For production, consider adding LoRA, ControlNet, Drive mounting, and better error handling.
